/***********************************************************************************************
* Program: Debugging.
* Programmer : Daudi Mlengela(dmlengela@cnm.edu)
* Date : 22 November 2021.
* Purpose : Debugging.
* ***********************************************************************************************/

#ifndef WIND_CHILL_H
#define WIND_CHILL_H

#include <iostream>
#include <cmath>
#include <string>
using namespace std;

void WriteHeader();
double AskForTemperature(); // paranthesis needed here
double AskForWindSpeed();
int ValidateTempAndWS(double temp, double speed);
double CalcWindChill(double T, double V); 
int DetermineFrostbiteTimes(double T, double V);
void Goodbye();
bool DoAgain();

#endif !_WIND_CHILL_H

