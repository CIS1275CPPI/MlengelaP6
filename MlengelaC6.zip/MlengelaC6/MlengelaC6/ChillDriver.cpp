/***********************************************************************************************
* Program: Debugging.
* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
* Date: 9 November 2021.
* Purpose: Debugging.
************************************************************************************************/

#include <iostream> // for cout and cin
#include "WindChill.h" // to include .h file for function prototype.
#include <string>
#include <cmath> 

using namespace std; // for standard name space
int main()
{

	cout << "\n\n CIS 1275   C6  Debugging Quiz Assignment:  Windchill & FrostBite"
		<< "\n This program crashes. Can you find and fix the crashing points?\n"
		<< "\n Place a comment above the line where the crash occurs"; // I add ; to free double below 
	// from squigglies. 

	double temp{ 0.0 };
	double wSpeed{ 0.0 }, wChill{ 0.0 };
	int returnCode{ 0 }, fBite{ 0 }; // there is typos. it need 'de' to be a complete match

	string answer{"yes"}; // We need to add r and ". It was typos. 


		//do while loop here
		do
		{
			//asked for temp

			temp = AskForTemperature();

			//asked for windspeed
			wSpeed = AskForWindSpeed();

			//validated temp and windspeed
			returnCode = ValidateTempAndWS(temp, wSpeed); // we need small letter w and t to match
			//return codes 0 = all OK, 1 = both invalid, 2 = temp invalid, 3 = wind invalid

			//if all ok
			if (returnCode == 0)
			{
				//calculate windchill
					wChill = CalcWindChill(temp, wSpeed); // letter t should be small to match usage
					// I copycat "CalcWindChill" from .h file to remove squigglies. 

					//calculate frostbite time
						fBite = DetermineFrostbiteTimes(temp, wSpeed); // both letter w and t 
						//should be small to match usage

						//show the user results
						cout << "\n\n Temperature is : " << temp;
						cout << "\n\n WindSpeed is : " << wSpeed;
						cout << "\n \n WindChill is : " << wChill; // letter w should be small
						if (fBite > 30 || fBite < 0) // letter b should be capital and f small 
							cout << "\n\n Forstbite is not an immediate threat.";
						else
							cout << "\n \n FrostBite is : " << fBite << " minutes. \n\n"; // Small f 
						// and capital b.

			}
			else if (returnCode == 1)
			{
			   cout << "\n\n Temperature and WindSpeed is Invalid ";
			}
			else if (returnCode == 2)
			{
			    cout << "\n\n Temperature is Invalid ";
			}
			else if (returnCode == 3)
			{
				cout << "\n\n WindSpeed is Invalid ";
			}
			else if (returnCode == 4)
			{
				cout << "\n\n These conditions mean instant death! DO NOT WALK OUTSIDE!";
			}

			cout << "\n\n Do You Want To Go Again? (yes/no) :";
			cin >> answer;
			cin.ignore();

		} while (DoAgain()); // Another closing parenthesis is needed. 

			Goodbye();

      return 0;
	}

